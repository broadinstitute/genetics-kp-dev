
CONFIG OPTIONS for cpp-pistache-server

	addExternalLibs
	    Add the Possibility to fetch and compile external Libraries needed by this Framework. (Default: true)

	helpersPackage
	    Specify the package name to be used for the helpers (e.g. org.openapitools.server.helpers). (Default: org.openapitools.server.helpers)

Back to the [generators list](README.md)
