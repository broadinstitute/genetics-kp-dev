
CONFIG OPTIONS for erlang-server

	packageName
	    Erlang package name (convention: lowercase). (Default: openapi)

	openAPISpecName
	    Openapi Spec Name. (Default: openapi)

Back to the [generators list](README.md)
