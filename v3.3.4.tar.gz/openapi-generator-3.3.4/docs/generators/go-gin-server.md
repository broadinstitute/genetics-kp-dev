
CONFIG OPTIONS for go-gin-server

	packageName
	    Go package name (convention: lowercase). (Default: openapi)

	hideGenerationTimestamp
	    Hides the generation timestamp when files are generated. (Default: true)

Back to the [generators list](README.md)
