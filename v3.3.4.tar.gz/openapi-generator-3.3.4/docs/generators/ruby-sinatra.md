
CONFIG OPTIONS for ruby-sinatra

Back to the [generators list](README.md)
