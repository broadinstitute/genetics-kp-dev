
CONFIG OPTIONS for mysql-schema

	defaultDatabaseName
	    Default database name for all MySQL queries (Default: )

	jsonDataTypeEnabled
	    Use special JSON MySQL data type for complex model properties. Requires MySQL version 5.7.8. Generates TEXT data type when disabled (Default: true)

Back to the [generators list](README.md)
