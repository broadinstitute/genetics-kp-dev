
CONFIG OPTIONS for rust-server

	packageName
	    Rust crate name (convention: snake_case). (Default: openapi_client)

	packageVersion
	    Rust crate version.

Back to the [generators list](README.md)
