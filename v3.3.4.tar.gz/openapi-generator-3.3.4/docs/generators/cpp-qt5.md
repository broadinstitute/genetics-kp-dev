
CONFIG OPTIONS for cpp-qt5

	sortParamsByRequiredFlag
	    Sort method arguments to place required parameters before optional parameters. (Default: true)

	ensureUniqueParams
	    Whether to ensure parameter names are unique in an operation (rename parameters that are not). (Default: true)

	allowUnicodeIdentifiers
	    boolean, toggles whether unicode identifiers are allowed in names or not, default is false (Default: false)

	prependFormOrBodyParameters
	    Add form or body parameters to the beginning of the parameter list. (Default: false)

	cppNamespace
	    C++ namespace (convention: name::space::for::api). (Default: OpenAPI)

	optionalProjectFile
	    Generate client.pri. (Default: true)

Back to the [generators list](README.md)
