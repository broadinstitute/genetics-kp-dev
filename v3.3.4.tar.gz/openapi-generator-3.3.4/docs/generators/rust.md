
CONFIG OPTIONS for rust

	packageName
	    Rust package name (convention: lowercase). (Default: openapi)

	packageVersion
	    Rust package version. (Default: 1.0.0)

	hideGenerationTimestamp
	    Hides the generation timestamp when files are generated. (Default: true)

	library
	    library template (sub-template) to use. (Default: hyper)
	        hyper - HTTP client: Hyper.
	        reqwest - HTTP client: Reqwest.

Back to the [generators list](README.md)
