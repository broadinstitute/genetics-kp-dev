
CONFIG OPTIONS for erlang-client

	packageName
	    Erlang application name (convention: lowercase). (Default: openapi)

	packageName
	    Erlang application version (Default: 1.0.0)

Back to the [generators list](README.md)
