
CONFIG OPTIONS for elm

	elmVersion
	    Elm version: 0.18, 0.19 (Default: 0.19)
	        0.19 - Elm 0.19
	        0.18 - Elm 0.18

	elmPrefixCustomTypeVariants
	    Prefix custom type variants (Default: false)

Back to the [generators list](README.md)
