
CONFIG OPTIONS for kotlin

	sourceFolder
	    source folder for generated code (Default: src/main/kotlin)

	packageName
	    Generated artifact package name. (Default: org.openapitools)

	groupId
	    Generated artifact package's organization (i.e. maven groupId). (Default: org.openapitools)

	artifactId
	    Generated artifact id (name of jar).

	artifactVersion
	    Generated artifact's package version. (Default: 1.0.0)

	enumPropertyNaming
	    Naming convention for enum properties: 'camelCase', 'PascalCase', 'snake_case', 'UPPERCASE', and 'original' (Default: camelCase)

	parcelizeModels
	    toggle "@Parcelize" for generated models

	dateLibrary
	    Option. Date library to use
	        string - String
	        java8 - Java 8 native JSR310
	        threetenbp - Threetenbp

	collectionType
	    Option. Collection type to use
	        array - kotlin.Array
	        list - kotlin.collections.List

Back to the [generators list](README.md)
