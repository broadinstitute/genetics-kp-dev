
CONFIG OPTIONS for flash

	packageName
	    flash package name (convention: package.name) (Default: org.openapitools)

	packageVersion
	    flash package version (Default: 1.0.0)

	invokerPackage
	    root package for generated code

	sourceFolder
	    source folder for generated code. e.g. flash

Back to the [generators list](README.md)
