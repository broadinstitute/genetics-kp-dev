
CONFIG OPTIONS for lua

	packageName
	    Lua package name (convention: single word). (Default: openapiclient)

	packageVersion
	    Lua package version. (Default: 1.0.0-1)

	hideGenerationTimestamp
	    Hides the generation timestamp when files are generated. (Default: true)

Back to the [generators list](README.md)
