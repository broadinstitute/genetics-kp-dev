
CONFIG OPTIONS for ruby-on-rails

	databaseAdapter
	    The adapter for database (e.g. mysql, sqlite). Default: sqlite (Default: sqlite)

Back to the [generators list](README.md)
