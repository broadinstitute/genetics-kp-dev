
CONFIG OPTIONS for csharp-dotnet2

	packageName
	    C# package name (convention: Camel.Case). (Default: Org.OpenAPITools)

	packageVersion
	    C# package version. (Default: 1.0.0)

	clientPackage
	    C# client package name (convention: Camel.Case). (Default: Org.OpenAPITools.Client)

Back to the [generators list](README.md)
