
CONFIG OPTIONS for scala-finch

	packageName
	    Finch package name (e.g. org.openapitools). (Default: org.openapitools)

	modelPackage
	    package for generated models

	apiPackage
	    package for generated api classes

Back to the [generators list](README.md)
