
CONFIG OPTIONS for eiffel

	packageName
	    Eiffel Cluster name (convention: lowercase). (Default: openapi)

	packageVersion
	    Eiffel package version. (Default: 1.0.0)

	hideGenerationTimestamp
	    Hides the generation timestamp when files are generated. (Default: true)

Back to the [generators list](README.md)
