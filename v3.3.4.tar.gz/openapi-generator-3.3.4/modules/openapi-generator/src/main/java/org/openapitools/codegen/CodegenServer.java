package org.openapitools.codegen;

import java.util.List;

public class CodegenServer {
    public String url;
    public String description;
    public List<CodegenServerVariable> variables;
}
