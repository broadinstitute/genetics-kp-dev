package org.openapitools.codegen;

import java.util.List;

public class CodegenServerVariable {
    public String name;
    public String defaultValue;
    public String description;
    public List<String> enumValues;
}
